def inputMessage_m():
    m = input("输入你要发送的信息")
    return(m)