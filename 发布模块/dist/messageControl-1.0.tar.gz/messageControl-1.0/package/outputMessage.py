def outputMessage_m():
    print("发送成功！！")