from distutils.core import setup

setup(name="messageControl",
      version="1.0",
      description="一个控制消息输入输出的工具",
      author="qiaoyang",
      author_email="935760346@qq.com",
      py_modules=["package.inputMessage","package.outputMessage"]
)